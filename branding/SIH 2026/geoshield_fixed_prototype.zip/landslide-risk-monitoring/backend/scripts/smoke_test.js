/**
 * End-to-end smoke test for the backend API.
 *
 * Exercises exactly the user journey from docs/STATUS.md's own
 * "Priority Order for MVP Demo" checklist, plus the fixes made in this
 * pass (real-time alert broadcast, the /api/predict proxy). Run this after
 * `node scripts/seed.js` against a live backend to get a real pass/fail
 * report instead of taking any of this on faith.
 *
 * Usage:
 *   node scripts/smoke_test.js [http://localhost:5000]
 */
const BASE = process.argv[2] || 'http://localhost:5000';
let pass = 0, fail = 0;

function check(name, cond, detail) {
  if (cond) { console.log(`  ✅ ${name}`); pass++; }
  else { console.log(`  ❌ ${name}${detail ? ' — ' + detail : ''}`); fail++; }
}

async function req(path, opts = {}) {
  const res = await fetch(`${BASE}${path}`, {
    ...opts,
    headers: { 'Content-Type': 'application/json', ...(opts.headers || {}) },
  });
  let body = null;
  try { body = await res.json(); } catch (_) { /* non-JSON */ }
  return { status: res.status, body };
}

async function main() {
  console.log(`\n🏔️  GeoShield backend smoke test — ${BASE}\n`);

  // 1. Health check
  const health = await req('/api/health');
  check('GET /api/health', health.status === 200 && health.body?.status === 'OK');

  // 2. Login as seeded admin
  const login = await req('/api/auth/login', {
    method: 'POST',
    body: JSON.stringify({ email: 'admin@landslide.gov.in', password: 'admin123' }),
  });
  check('POST /api/auth/login (seeded admin)', login.status === 200 && !!login.body?.token,
    'run `node scripts/seed.js` first if this fails');
  const token = login.body?.token;
  const auth = { Authorization: `Bearer ${token}` };
  if (!token) {
    console.log('\n⛔ Cannot continue without a token — stopping here.\n');
    process.exit(1);
  }

  // 3. Dashboard stats (aggregation pipelines actually run)
  const stats = await req('/api/dashboard/stats', { headers: auth });
  check('GET /api/dashboard/stats', stats.status === 200 && stats.body?.stats?.riskZones,
    JSON.stringify(stats.body));

  // 4. Risk zones (GeoJSON for the map)
  const zones = await req('/api/risk-zones', { headers: auth });
  check('GET /api/risk-zones', zones.status === 200 && Array.isArray(zones.body?.zones));

  // 5. Issue an alert — demo priority #3, now wired to Socket.IO broadcast
  const newAlert = await req('/api/alerts', {
    method: 'POST',
    headers: auth,
    body: JSON.stringify({
      title: 'Smoke test alert', district: 'Kamrup', severity: 'high',
      type: 'landslide_warning', triggeredBy: 'manual',
      message: 'Automated smoke test — safe to resolve/delete.',
    }),
  });
  check('POST /api/alerts (issue)', newAlert.status === 201 && !!newAlert.body?.alert?._id,
    JSON.stringify(newAlert.body));
  const alertId = newAlert.body?.alert?._id;

  // 6. Resolve it
  if (alertId) {
    const resolved = await req(`/api/alerts/${alertId}/resolve`, { method: 'POST', headers: auth });
    check('POST /api/alerts/:id/resolve', resolved.status === 200 && resolved.body?.alert?.status === 'resolved');
  } else {
    check('POST /api/alerts/:id/resolve', false, 'skipped — no alert id from previous step');
  }

  // 7. Submit a field report — demo priority #4
  const report = await req('/api/field-reports', {
    method: 'POST',
    headers: auth,
    body: JSON.stringify({
      category: 'crack', title: 'Smoke test field report',
      description: 'Automated smoke test — safe to resolve/delete.', district: 'Kamrup',
      location: { type: 'Point', coordinates: [91.58, 26.22] },
    }),
  });
  check('POST /api/field-reports', report.status === 201 && !!report.body?.report?._id,
    JSON.stringify(report.body));

  // 8. AI prediction proxy (backend -> ML service, newly wired up)
  const predict = await req('/api/predict/25.58/91.89', {
    method: 'POST', headers: auth,
    body: JSON.stringify({ slope: 40, rainfall_7days: 300, ndvi: 0.2, soil_moisture: 0.8 }),
  });
  check('POST /api/predict/:lat/:lng', predict.status === 200 && !!predict.body?.prediction?.risk_level,
    JSON.stringify(predict.body) + ' — is the ML service running on :8000?');

  // 9. Weather (demo priority #5)
  const weather = await req('/api/weather/Kamrup', { headers: auth });
  check('GET /api/weather/:district', weather.status === 200);

  console.log(`\n${pass} passed, ${fail} failed.\n`);
  process.exit(fail > 0 ? 1 : 0);
}

main().catch((e) => { console.error('Smoke test crashed:', e); process.exit(1); });
