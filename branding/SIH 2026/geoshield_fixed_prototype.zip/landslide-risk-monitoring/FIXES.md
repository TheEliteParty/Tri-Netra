# FIXES.md — What was actually broken and what I changed

This is an honest changelog from an audit pass on the existing repo, not a
rewrite. Every item below was reproduced (not assumed) before being called a
bug. Ordered by how much it would have hurt at the SIH demo table.

## 🔴 Would have broken the demo outright

1. **Frontend couldn't even `npm install`.**
   `package.json` pinned React 19, but `react-leaflet@4.2.1` (the map
   library the whole dashboard's map page depends on) requires React 18 as
   a peer dependency. A clean `npm install` — literally the first command
   in the README — failed with an unresolvable `ERESOLVE` error.
   **Fix:** pinned `react` / `react-dom` / `@types/react*` to 18.3.x.
   Verified: clean install + `npm run build` now both succeed.

2. **Docker Compose path would 404 every single API call.**
   `docker-compose.yml` set `REACT_APP_API_URL=http://localhost:5000`
   (no `/api` suffix), but every axios call in `frontend/admin-dashboard/
   src/services/api.ts` is built on a base URL that's expected to already
   include `/api` (`http://localhost:5000/api` is the code's own fallback
   default). Since the frontend Dockerfile runs `npm start` (the CRA dev
   server, which reads env vars live, not baked at a separate build step),
   this env var actively overrides the correct default — so the
   "recommended" Docker path in the README would have served a dashboard
   where every API request 404'd. **Fix:** corrected the compose env var to
   include `/api`. Also fixed `REACT_APP_ML_SERVICE_URL` → `REACT_APP_ML_URL`
   (the name the code actually reads) for the same reason, and added a
   missing `frontend/admin-dashboard/.env.example`.

3. **`npm run seed` pointed at a file that doesn't exist.**
   `backend/package.json`'s `seed` script ran `node scripts/seedData.js` —
   the actual file is `scripts/seed.js`. Every direct call in the README
   and `start.sh` uses the correct filename, so this only broke the one
   `npm run seed` shortcut, but it's exactly the kind of thing that eats
   ten confused minutes right before a demo. **Fix:** corrected the path;
   also added an `npm run smoke-test` shortcut for the script below.

## 🟠 Silently undermined the actual AI/ML claim

3. **The rainfall feature was zeroed out during training.**
   `ml-service/scripts/train_model.py` renames the raw column
   `rainfall_7day` → `rainfall_7days`, then immediately looks for
   `rainfall_7day` (the pre-rename name) when building the feature matrix.
   Since that column no longer existed after the rename, the "ensure all
   feature columns exist" fallback silently created a new all-zero column
   under that name. **The model that's supposed to be a rainfall-triggered
   landslide predictor was being trained with zero rainfall signal** — this
   showed up as `rainfall_7day` having exactly `0.000` feature importance.
   **Fix:** standardized on `rainfall_7days` everywhere (matches the actual
   API request schema and the inference code, which were already correct).
   Retrained: rainfall now sits at ~0.118 importance, on par with slope and
   soil moisture — where it should be.

4. **The in-app `/train` retrain button produced a model that could never
   detect a landslide.** `utils/model.py`'s `LandslidePredictor.train()`
   (used by the `POST /train` API endpoint) didn't correct for class
   imbalance. On the ~7%-positive synthetic set it uses, this produced a
   model with 93.5% "accuracy" but **0.0 precision, 0.0 recall, 0.0 F1 on
   the landslide class** — it never once predicted a landslide, on any
   input. A judge clicking "retrain" mid-demo would have silently swapped
   in a useless model. **Fix:** added `scale_pos_weight` (same fix the
   command-line training script already had).

5. **`GET /risk/grid` crashed with a 500 error.** `pd.linspace` doesn't
   exist — that's a numpy function, not pandas. This endpoint backs the
   heatmap overlay. **Fix:** `np.linspace`, with the missing `numpy` import
   added.

## 🟡 Real features that were wired up incompletely

6. **Role-based Socket.IO rooms were referenced but never joined.**
   `field_report` broadcasts targeted a `role:admin` room, but no code
   anywhere ever called `socket.join('role:admin')`. Any real-time
   admin-targeted broadcast was going to an empty room. **Fix:** clients
   now join `role:<their role>` on authenticate.

7. **Issuing or resolving an alert never touched Socket.IO at all.**
   Despite "real-time Socket.IO broadcasting" being a headline feature and
   "issue an alert, watch it go live" being the team's own #1 MVP demo
   priority (`docs/STATUS.md`), `POST /api/alerts` and
   `POST /api/alerts/:id/resolve` only wrote to MongoDB — no broadcast. It
   would only have shown up for other users on a manual page refresh, not
   live. **Fix:** both routes now call the socket handler's
   `broadcastAlert()`. Field report submission was in the same situation
   (only the *mobile client* could trigger a live push, and only if it
   happened to have its own separate socket connection open) — now the
   backend pushes it directly after the HTTP POST succeeds, which is more
   robust.

8. **The documented `POST /api/predict/:lat/:lng` endpoint didn't exist.**
   The README's own API table lists it, and a whole `predictionService.js`
   (with a rule-based fallback for when the ML service is down) was
   written for it — but no route ever called that service. The dashboard
   happened to work anyway because it calls the ML service directly from
   the browser, bypassing the backend entirely. **Fix:** added the route,
   so the documented API surface is now real, and so a future mobile/other
   client only needs to reach the backend, not the ML service directly.

## 🟢 Structural gap (flagged, not silently left)

9. **The mobile app had no React Native scaffold at all** — no `index.js`
   entry point, `tsconfig.json`, `babel.config.js`, `metro.config.js`, or
   `app.json`. The screens under `src/` exist and read fine, but there was
   nothing to actually launch them with `react-native run-android`.
   Restored the JS-level scaffold files. **Still needed on your end:**
   native `android/`/`ios/` project folders, normally generated by the RN
   CLI itself (`npx @react-native-community/cli init`) — that's a
   toolchain-specific step I can't fabricate meaningfully from here.

## What I verified myself vs. what still needs your machine

**Actually ran and confirmed working here:** the full ML pipeline (dataset
generation → training → all 6 FastAPI endpoints), the backend's syntax
across every file, `npm install` + production build for the dashboard.

**Could not run a real MongoDB in this sandbox** — no `mongod` package in
apt, no Docker, and the only binary distribution path (`fastdl.mongodb.org`,
which every Node MongoDB testing tool from `mongodb-memory-server` on down
ultimately downloads from) sits outside this environment's network access.
I checked all of these directly rather than assuming.

So instead of a mock (which would only prove my mock is self-consistent,
not that your actual stack works), **I added a real `integration` job to
`.github/workflows/ci.yml`** that spins up an actual `mongo:7` service
container on GitHub's runners, seeds it, boots the real backend and ML
service, and runs `backend/scripts/smoke_test.js` against them for real.
Push this branch (or open a PR) and check the Actions tab — that gives you
a genuine pass/fail on your real code within about a minute, not an
approximation. You can also run the same smoke test locally the moment you
have Mongo up: `cd backend && npm run smoke-test`.
